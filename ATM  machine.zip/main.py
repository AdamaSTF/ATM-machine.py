from authen_module import user_authen
from user_requirements import balance_req, withdraw_req, deposit_req
from user_data import balance

def main_menu():
    """
    Main menu for the ATM system.
    """
    username = user_authen()
    if not username:
        return
    else:
        while True:
            print("\nChoose an option:")
            print("1. Current balance check")
            print("2. Withdraw")
            print("3. Deposit")
            print("4. Exit")

            try: 
                user_req = int(input("Enter your choice (1-4): "))
                if user_req == 1:
                    balance(username)
                elif user_req == 2:
                    withdraw_req(username)
                elif user_req == 3:
                    deposit_req(username)
                elif user_req == 4:
                    print("Thank you for using this ATM. See you later!")
                    break
                    
                else: 
                    print("Invalid option, please try again.")
            except ValueError:
                print("Invalid input, please enter a number between 1 and 4.")
        

