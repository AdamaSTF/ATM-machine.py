
usernames = {
    "Jrtall_1": {"pin": "1812", "balance": 300},
    "juice_b": {"pin": "1807", "balance": 540},
    "aplle_2": {"pin": "1809", "balance": 1200}
}

def balance(username):
    """
    Retrieves the balance for a specific user.
    """
    return usernames[username]["balance"]

def updated_balance(username, new_balance):
    """
    Updates the balance for a specific user.
    """
    usernames[username]["balance"] = new_balance
