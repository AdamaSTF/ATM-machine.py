from user_data import usernames

def user_authen(usernames):
    """
    Authenticates the user by username and PIN.
    Returns the authenticated username or None if authentication fails.
    """
    attempts = 0
    max_attempts = 3

    while attempts < max_attempts:
        user_usernames = input("Please enter your username: ")
        
        if user_usernames in usernames:
            pin = input("Please enter your 4-digit code : ")
            if usernames[user_usernames]["pin"] == pin:
                print(f"Welcome {user_usernames}!")
                
            else:
                print("Invalid PIN number, please try again!")
        else:
            print("Username not found, please try again!")

        attempts += 1  # adding one attempts to the counter 

        print("Maximum attempts reached. Authentication failed.")
        break # breaking the loops if 3 unssuccesful attemps 

authenticated_user = user_authen(usernames)

