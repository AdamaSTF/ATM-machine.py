from user_data import balance, updated_balance

def balance_req(username):# allowing authenticated user to see their account balance"
    balance_req = balance(username)
    print(f"You have £{balance:.2f} in your account.")

def withdraw_req(username): #allowing authenticated user to withdraw
   
    try:
        amount2_withdraw = float(input("Please enter the amount you want to withdraw: "))
        balance = balance_req(username)
        if amount2_withdraw > balance:
            print(f"You do not have enough money in your account. Your current balance is £{balance:.2f}.")
        elif amount2_withdraw > 0:
            new_balance = balance - amount2_withdraw
            updated_balance(username, new_balance)
            print(f"Withdrawal successful! £{amount2_withdraw:.2f} has been withdrew from your account.")
        else:
            print("Invalid amount, please try again!")
    except ValueError:
        print("Invalid input, please try again.")

def deposit_req(username):# allowing authenticated user to deposit 
    """
    Handles deposit requests for the authenticated user.
    """
    try:
        amount2_deposit = float(input("Please enter the amount you want to deposit: "))
        if amount2_deposit > 0:
            balance = balance_req(username)
            new_balance = balance + amount2_deposit
            updated_balance(username, new_balance)
            print(f"Deposit successful! £{amount2_deposit:.2f} has been added to your account.")
        else:
            print("Invalid amount, please try again!")
    except ValueError:
        print("Invalid input, please try again!")
